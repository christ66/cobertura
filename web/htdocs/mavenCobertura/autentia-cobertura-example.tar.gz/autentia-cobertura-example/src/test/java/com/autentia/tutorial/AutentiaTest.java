package com.autentia.tutorial;

import org.junit.Test;

public class AutentiaTest {

	@Test
	public void testApp() {
		final Autentia autentia = new Autentia();

		autentia.tellMeSometing(3);

		autentia.tellMeSometing(6);
		
// Descomenra la líena de abajo para conseguir un 100% de cobertura
//		autentia.tellMeSometing(7);
		
	}
}
